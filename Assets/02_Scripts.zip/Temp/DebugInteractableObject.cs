using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class DebugInteractableObject : MonoBehaviour, IInteractable
{
    [SerializeField] private string interactionText = "��ȣ�ۿ�";

    public string InteractionText => interactionText;

    public bool CanInteract(GameObject interactor)
    {
        return true;
    }

    public void Interact(GameObject interactor)
    {
        Debug.Log($"{name} ��ȣ�ۿ� ����");
    }
}