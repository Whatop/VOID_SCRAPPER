using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "VOID SCRAPPER/Traits/Ship Trait Definition")]
public class ShipTraitDefinition : ScriptableObject
{
    [Header("Identity")]
    [SerializeField] private string traitId;
    [SerializeField] private string displayName;
    [TextArea]
    [SerializeField] private string description;
    [SerializeField] private Sprite icon;

    [Header("Ship Requirement")]
    [SerializeField] private bool availableForAllShips;
    [SerializeField] private string requiredShipId = "basic_ship";

    [Header("Tree Position")]
    [Tooltip("���� ���� �ܰ�. 1-2-3-4 �������� 1, 2, 3, 4.")]
    [SerializeField] private int stage = 1;

    [Tooltip("���� �б� ����. 0�� �߾�, -1�� ��, 1�� �Ʒ�.")]
    [SerializeField] private int lane = 0;

    [Tooltip("�ڵ� ��ġ ��� ���� ��ǥ�� ���� ����.")]
    [SerializeField] private bool useCustomAnchoredPosition;

    [SerializeField] private Vector2 customAnchoredPosition;

    [Header("Prerequisites")]
    [Tooltip("�� Ư���� �ر��ϱ� ���� ���� �رݵǾ�� �ϴ� Ư�� ID ���.")]
    [SerializeField] private List<string> prerequisiteTraitIds = new List<string>();

    [Header("Unlock Cost")]
    [SerializeField] private int scrapCost = 10;
    [SerializeField] private int coreShardCost;

    [Header("Effects")]
    [SerializeField] private List<TraitLevelEffect> effects = new List<TraitLevelEffect>();

    public string TraitId => string.IsNullOrWhiteSpace(traitId) ? name : traitId;
    public string DisplayName => string.IsNullOrWhiteSpace(displayName) ? TraitId : displayName;
    public string Description => string.IsNullOrWhiteSpace(description) ? "Ư�� ������ �����ϴ�." : description;
    public Sprite Icon => icon;

    public bool AvailableForAllShips => availableForAllShips;
    public string RequiredShipId => string.IsNullOrWhiteSpace(requiredShipId) ? "basic_ship" : requiredShipId;

    public int Stage => Mathf.Max(1, stage);
    public int Lane => lane;

    public bool UseCustomAnchoredPosition => useCustomAnchoredPosition;
    public Vector2 CustomAnchoredPosition => customAnchoredPosition;

    public IReadOnlyList<string> PrerequisiteTraitIds => prerequisiteTraitIds;

    public int ScrapCost => Mathf.Max(0, scrapCost);
    public int CoreShardCost => Mathf.Max(0, coreShardCost);

    public IReadOnlyList<TraitLevelEffect> Effects => effects;

    public bool BelongsToShip(string shipId)
    {
        if (availableForAllShips)
        {
            return true;
        }

        if (string.IsNullOrWhiteSpace(shipId))
        {
            return false;
        }

        return RequiredShipId == shipId;
    }
}