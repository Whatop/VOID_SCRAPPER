using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class MeteorObstacle : MonoBehaviour
{
    [Header("Meteor Settings")]
    [SerializeField] private int maxHp = 3;                  // � �ִ� ü��
    [SerializeField] private float minDriftSpeed = 0.4f;     // �ּ� �̵� �ӵ�
    [SerializeField] private float maxDriftSpeed = 1.2f;     // �ִ� �̵� �ӵ�
    [SerializeField] private float minSpinSpeed = -50f;      // �ּ� ȸ�� �ӵ�
    [SerializeField] private float maxSpinSpeed = 50f;       // �ִ� ȸ�� �ӵ�
    [SerializeField] private float boundsPadding = 0.5f;     // �� ��迡�� �ݻ�� �� ����ϴ� ������

    [Header("Hit Effect")]
    [SerializeField] private GameObject hitEffectPrefab;     // �ǰ� ����Ʈ ������
    [SerializeField] private float hitEffectDuration = 0.12f;

    private int currentHp;
    private Vector2 moveDirection;
    private float moveSpeed;
    private float spinSpeed;

    private Bounds roamingBounds;
    private bool hasRoamingBounds;

    private void OnEnable()
    {
        currentHp = maxHp;
        RandomizeMovement();
    }

    private void Update()
    {
        transform.position += (Vector3)(moveDirection * moveSpeed * Time.deltaTime);
        transform.Rotate(0f, 0f, spinSpeed * Time.deltaTime);
        HandleBoundsBounce();
    }

    /// <summary>
    /// �����ʰ� ������ �� ��� �ȿ��� ��� �����ƴٴϵ��� ������ �����մϴ�.
    /// </summary>
    public void SetRoamingBounds(Bounds bounds)
    {
        roamingBounds = bounds;
        hasRoamingBounds = true;
    }

    /// <summary>
    /// �Ѿ��� ��� �¾��� �� ȣ��˴ϴ�.
    /// ��� ��� �Ѿ��� ���� ��ֹ� ������ �մϴ�.
    /// </summary>
    public void TakeDamage(int damage)
    {
        currentHp -= damage;
        SpawnHitEffect();
        AudioManager.PlayAt(SoundEventIds.ObjectMeteorHit, transform.position, 0.65f);

        if (currentHp <= 0)
        {
            ReleaseSelf();
        }
    }

    private void RandomizeMovement()
    {
        float angle = Random.Range(0f, 360f) * Mathf.Deg2Rad;
        moveDirection = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)).normalized;
        moveSpeed = Random.Range(minDriftSpeed, maxDriftSpeed);
        spinSpeed = Random.Range(minSpinSpeed, maxSpinSpeed);
    }

    private void HandleBoundsBounce()
    {
        if (!hasRoamingBounds)
        {
            return;
        }

        Vector3 position = transform.position;
        bool bounced = false;

        if (position.x <= roamingBounds.min.x + boundsPadding && moveDirection.x < 0f)
        {
            moveDirection.x *= -1f;
            position.x = roamingBounds.min.x + boundsPadding;
            bounced = true;
        }
        else if (position.x >= roamingBounds.max.x - boundsPadding && moveDirection.x > 0f)
        {
            moveDirection.x *= -1f;
            position.x = roamingBounds.max.x - boundsPadding;
            bounced = true;
        }

        if (position.y <= roamingBounds.min.y + boundsPadding && moveDirection.y < 0f)
        {
            moveDirection.y *= -1f;
            position.y = roamingBounds.min.y + boundsPadding;
            bounced = true;
        }
        else if (position.y >= roamingBounds.max.y - boundsPadding && moveDirection.y > 0f)
        {
            moveDirection.y *= -1f;
            position.y = roamingBounds.max.y - boundsPadding;
            bounced = true;
        }

        if (bounced)
        {
            transform.position = position;
        }
    }

    private void SpawnHitEffect()
    {
        if (hitEffectPrefab == null || PoolManager.Instance == null)
        {
            return;
        }

        PoolManager.Instance.SpawnAutoRelease(hitEffectPrefab, transform.position, hitEffectDuration);
    }

    private void ReleaseSelf()
    {
        AudioManager.PlayAt(SoundEventIds.ObjectMeteorBreak, transform.position);

        if (PoolManager.Instance != null)
        {
            PoolManager.Instance.Release(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
