using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(EnemyHealth))]
public class BossDummyController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private EnemyHealth enemyHealth;

    [Header("Exit Object Prefabs")]
    [SerializeField] private GameObject returnBeaconPrefab;
    [SerializeField] private GameObject wormholePortalPrefab;

    [Header("Spawn Positions")]
    [SerializeField] private bool useBossDeathPosition = true;

    [Tooltip("��ȯ ������ ��Ȧ�� ��ġ�� �ʰ� ���� ��� ��ġ �������� ��¦ ���� �����մϴ�.")]
    [SerializeField] private Vector2 returnBeaconSpawnOffset = new Vector2(-1.5f, 0f);

    [Tooltip("��Ȧ�� �⺻������ ������ ���� ��ġ�� �����մϴ�.")]
    [SerializeField] private Vector2 wormholeSpawnOffset = Vector2.zero;

    [Header("External Config Optional")]
    [SerializeField] private bool hasConfiguredReturnBeaconPosition;
    [SerializeField] private Vector3 configuredReturnBeaconPosition;

    [SerializeField] private bool hasConfiguredWormholePosition;
    [SerializeField] private Vector3 configuredWormholePosition;

    [Header("Deep Zone Reward")]
    [SerializeField] private bool grantDeepZoneAdditionalCoreDirectly = true;
    [SerializeField] private int deepZoneAdditionalCoreShards = 1;

    [Header("State")]
    [SerializeField] private bool changeStateToExpeditionAfterDeath = true;

    private bool deathHandled;

    private void Reset()
    {
        enemyHealth = GetComponent<EnemyHealth>();
    }

    private void Awake()
    {
        if (enemyHealth == null)
        {
            enemyHealth = GetComponent<EnemyHealth>();
        }
    }

    private void OnEnable()
    {
        deathHandled = false;

        if (enemyHealth != null)
        {
            enemyHealth.Died += HandleBossDied;
        }
    }

    private void OnDisable()
    {
        if (enemyHealth != null)
        {
            enemyHealth.Died -= HandleBossDied;
        }
    }

    // ���� CoreObject �ڵ�� ȣȯ��.
    // �������� ��ȯ ���� ��ġ�� CoreObject���� �Ѱ���� ������ �״�� �����Ѵ�.
    public void ConfigureReturnBeacon(GameObject beaconPrefab, Vector3 spawnPosition)
    {
        returnBeaconPrefab = beaconPrefab;
        configuredReturnBeaconPosition = spawnPosition;
        hasConfiguredReturnBeaconPosition = true;
    }

    // �� ������.
    // CoreObject���� �� �� �ѱ�� ������ �� �޼��带 ȣ���ϸ� �ȴ�.
    public void ConfigureExitObjects(
        GameObject beaconPrefab,
        Vector3 beaconSpawnPosition,
        GameObject wormholePrefab,
        Vector3 wormholeSpawnPosition)
    {
        returnBeaconPrefab = beaconPrefab;
        configuredReturnBeaconPosition = beaconSpawnPosition;
        hasConfiguredReturnBeaconPosition = true;

        wormholePortalPrefab = wormholePrefab;
        configuredWormholePosition = wormholeSpawnPosition;
        hasConfiguredWormholePosition = true;
    }

    private void HandleBossDied(EnemyHealth health)
    {
        if (deathHandled)
        {
            return;
        }

        deathHandled = true;

        if (RunManager.Instance != null && RunManager.Instance.HasActiveRun)
        {
            RunManager.Instance.MarkBossDefeated();

            if (grantDeepZoneAdditionalCoreDirectly &&
                RunManager.Instance.CurrentRun.ExpeditionDepth == ExpeditionDepth.DeepZone1 &&
                deepZoneAdditionalCoreShards > 0)
            {
                RunManager.Instance.AddCurrency(CurrencyType.CoreShards, deepZoneAdditionalCoreShards);
            }
        }

        SpawnReturnBeacon();
        SpawnWormholePortal();

        if (changeStateToExpeditionAfterDeath && GameStateManager.Instance != null)
        {
            GameStateManager.Instance.ChangeState(GameState.Expedition);
        }
    }

    private void SpawnReturnBeacon()
    {
        if (returnBeaconPrefab == null)
        {
            Debug.LogWarning("���� ��� �� ������ returnBeaconPrefab�� �����ϴ�.", this);
            return;
        }

        Vector3 spawnPosition = ResolveReturnBeaconSpawnPosition();
        Instantiate(returnBeaconPrefab, spawnPosition, Quaternion.identity);
    }

    private void SpawnWormholePortal()
    {
        if (wormholePortalPrefab == null)
        {
            Debug.LogWarning("���� ��� �� ������ wormholePortalPrefab�� �����ϴ�.", this);
            return;
        }

        Vector3 spawnPosition = ResolveWormholeSpawnPosition();
        Instantiate(wormholePortalPrefab, spawnPosition, Quaternion.identity);
    }

    private Vector3 ResolveReturnBeaconSpawnPosition()
    {
        if (hasConfiguredReturnBeaconPosition)
        {
            return configuredReturnBeaconPosition;
        }

        Vector3 basePosition = useBossDeathPosition ? transform.position : Vector3.zero;
        return basePosition + (Vector3)returnBeaconSpawnOffset;
    }

    private Vector3 ResolveWormholeSpawnPosition()
    {
        if (hasConfiguredWormholePosition)
        {
            return configuredWormholePosition;
        }

        Vector3 basePosition = useBossDeathPosition ? transform.position : Vector3.zero;
        return basePosition + (Vector3)wormholeSpawnOffset;
    }
}