using UnityEngine;

[DisallowMultipleComponent]
public class WormholePortal : MonoBehaviour, IInteractable
{
    [Header("Interaction")]
    [SerializeField] private string interactionText = "��Ȧ ����";
    [SerializeField] private bool requireBossDefeated = true;
    [SerializeField] private bool normalZoneOnly = true;

    [Header("UI")]
    [SerializeField] private WormholeChoiceUI wormholeChoiceUI;

    [Header("Debug")]
    [SerializeField] private bool logBlockReason = true;

    [Header("Optional")]
    [SerializeField] private RadarTarget radarTarget;

    public string InteractionText => interactionText;

    private void Reset()
    {
        radarTarget = GetComponent<RadarTarget>();
    }

    private void Awake()
    {
        if (radarTarget == null)
        {
            radarTarget = GetComponent<RadarTarget>();
        }

        if (wormholeChoiceUI == null)
        {
            wormholeChoiceUI = FindFirstObjectByType<WormholeChoiceUI>();
        }
    }

    public bool CanInteract(GameObject interactor)
    {
        if (interactor == null)
        {
            LogBlock("interactor�� null�Դϴ�.");
            return false;
        }

        if (RunManager.Instance == null)
        {
            LogBlock("RunManager.Instance�� �����ϴ�.");
            return false;
        }

        if (!RunManager.Instance.HasActiveRun)
        {
            LogBlock("Ȱ�� Run�� �����ϴ�.");
            return false;
        }

        if (requireBossDefeated && !RunManager.Instance.CurrentRun.BossDefeated)
        {
            LogBlock("������ ���� óġ���� �ʾҽ��ϴ�. �׽�Ʈ ���̸� Require Boss Defeated�� ������.");
            return false;
        }

        if (normalZoneOnly &&
            RunManager.Instance.CurrentRun.ExpeditionDepth != ExpeditionDepth.Normal)
        {
            LogBlock("���� ������ Normal�� �ƴմϴ�. �ɺ� �ؿ������� ��Ȧ ������ ���� �ֽ��ϴ�.");
            return false;
        }

        return true;
    }

    public void Interact(GameObject interactor)
    {
        if (!CanInteract(interactor))
        {
            return;
        }

        if (wormholeChoiceUI == null)
        {
            wormholeChoiceUI = FindFirstObjectByType<WormholeChoiceUI>();
        }

        if (wormholeChoiceUI != null)
        {
            wormholeChoiceUI.Open(this);
            return;
        }

        ConfirmEnterNextArea();
    }

    public void ConfirmEnterNextArea()
    {
        if (RunManager.Instance == null || !RunManager.Instance.HasActiveRun)
        {
            return;
        }

        if (normalZoneOnly &&
            RunManager.Instance.CurrentRun.ExpeditionDepth != ExpeditionDepth.Normal)
        {
            return;
        }

        RunManager.Instance.EnterDeepZone1();
    }

    private void LogBlock(string reason)
    {
        if (!logBlockReason)
        {
            return;
        }

        Debug.Log($"[WormholePortal] ��ȣ�ۿ� �Ұ�: {reason}", this);
    }
}