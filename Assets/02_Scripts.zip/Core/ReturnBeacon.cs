using UnityEngine;

[DisallowMultipleComponent]
public class ReturnBeacon : MonoBehaviour, IInteractable
{
    [Header("Interaction")]
    [SerializeField] private string interactionText = "��ȯ ���� ���";
    [SerializeField] private string returningText = "���� ���� ó�� ��";
    [SerializeField] private bool requireBossDefeated = true;

    [Header("UI")]
    [SerializeField] private ReturnChoiceUI returnChoiceUI;

    private bool returning;
    private Collider2D beaconCollider;

    public string InteractionText => returning ? returningText : interactionText;

    private void Awake()
    {
        beaconCollider = GetComponent<Collider2D>();

        if (returnChoiceUI == null)
        {
            returnChoiceUI = FindFirstObjectByType<ReturnChoiceUI>();
        }
    }

    public bool CanInteract(GameObject interactor)
    {
        if (returning)
        {
            return false;
        }

        if (interactor == null)
        {
            return false;
        }

        if (RunManager.Instance == null || !RunManager.Instance.HasActiveRun)
        {
            return false;
        }

        if (requireBossDefeated && !RunManager.Instance.CurrentRun.BossDefeated)
        {
            return false;
        }

        return true;
    }

    public void Interact(GameObject interactor)
    {
        if (!CanInteract(interactor))
        {
            return;
        }

        if (returnChoiceUI == null)
        {
            returnChoiceUI = FindFirstObjectByType<ReturnChoiceUI>();
        }

        if (returnChoiceUI != null)
        {
            returnChoiceUI.Open(this);
            return;
        }

        ConfirmReturn();
    }

    public void ConfirmReturn()
    {
        if (returning)
        {
            return;
        }

        if (RunManager.Instance == null || !RunManager.Instance.HasActiveRun)
        {
            return;
        }

        returning = true;

        RunManager.Instance.CompleteRun(RunEndReason.SafeReturn);

        // ���⼭ �� �̵��ϸ� �� ��.
        // ����â ContinueButton�� ������ �̵��� ����Ѵ�.
    }
}