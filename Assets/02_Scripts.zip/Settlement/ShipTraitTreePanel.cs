using System;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[Serializable]
public class ShipTraitBranchNodeEntry
{
    public ShipTraitBranchKind branchKind;

    [Header("Node Identity")]
    public string nodeId;
    public ShipTraitNodeButton nodeButton;

    [Header("Display")]
    public string displayName;
    public Sprite icon;

    [TextArea]
    public string description;

    [Header("Cost / Level")]
    [Min(0)]
    public int scrapCost;

    [Min(0)]
    public int coreShardCost;

    [Min(1)]
    public int maxLevel = 1;

    [Header("Branch Activation By Ship Unlock")]
    [Min(0)]
    public int requiredUnlockedShipCount = 1;

    public string requiredShipId;
    public string requiredUnlockFlag;

    [Header("Tree Prerequisites")]
    public List<string> prerequisiteNodeIds = new List<string>();

    [Header("Option")]
    public bool hideWhenLocked;
}

public class ShipTraitTreePanel : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private SettlementController settlementController;

    [Header("Branch Panel Objects")]
    [SerializeField] private GameObject sharedPanelObject;
    [SerializeField] private GameObject machineGunPanelObject;
    [SerializeField] private GameObject sniperPanelObject;
    [SerializeField] private GameObject shotgunPanelObject;
    [SerializeField] private bool deactivateBranchPanelWhenLocked = true;

    [Header("Static Nodes In ScrollView")]
    [SerializeField] private List<ShipTraitBranchNodeEntry> branchNodes = new List<ShipTraitBranchNodeEntry>();

    [Header("Ship Catalog")]
    [SerializeField] private List<ShipDefinition> shipDefinitions = new List<ShipDefinition>();

    [Header("Target Ship Optional")]
    [SerializeField] private string targetShipIdOverride;

    [Header("Detail UI")]
    [SerializeField] private Image selectedIconImage;
    [SerializeField] private TextMeshProUGUI titleText;
    [SerializeField] private TextMeshProUGUI bodyText;
    [SerializeField] private TextMeshProUGUI costText;
    [SerializeField] private TextMeshProUGUI statusText;
    [SerializeField] private TextMeshProUGUI messageText;

    [Header("Unlock Button")]
    [SerializeField] private Button unlockButton;
    [SerializeField] private TextMeshProUGUI unlockButtonLabelText;

    private ShipTraitBranchKind selectedBranch = ShipTraitBranchKind.Shared;
    private string selectedNodeId;
    private bool hasSelection;

    public Button UnlockButton => unlockButton;
    public ShipTraitBranchKind SelectedBranch => selectedBranch;
    public string SelectedNodeId => selectedNodeId;
    public bool HasSelection => hasSelection;

    private void Reset()
    {
        branchNodes = new List<ShipTraitBranchNodeEntry>
        {
            new ShipTraitBranchNodeEntry
            {
                branchKind = ShipTraitBranchKind.Shared,
                nodeId = "shared_01",
                displayName = "���� Ư�� 1",
                description = "���� Ư�� ù ��° ����Դϴ�.",
                requiredUnlockedShipCount = 1,
                maxLevel = 1
            },
            new ShipTraitBranchNodeEntry
            {
                branchKind = ShipTraitBranchKind.Shared,
                nodeId = "shared_02",
                displayName = "���� Ư�� 2",
                description = "���� Ư�� �� ��° ����Դϴ�.",
                requiredUnlockedShipCount = 1,
                prerequisiteNodeIds = new List<string> { "shared_01" },
                maxLevel = 1
            },
            new ShipTraitBranchNodeEntry
            {
                branchKind = ShipTraitBranchKind.Shared,
                nodeId = "shared_03",
                displayName = "���� Ư�� 3",
                description = "���� Ư�� �� ��° ����Դϴ�.",
                requiredUnlockedShipCount = 1,
                prerequisiteNodeIds = new List<string> { "shared_02" },
                maxLevel = 1
            },
            new ShipTraitBranchNodeEntry
            {
                branchKind = ShipTraitBranchKind.Shared,
                nodeId = "shared_04",
                displayName = "���� Ư�� 4",
                description = "���� Ư�� �� ��° ����Դϴ�.",
                requiredUnlockedShipCount = 1,
                prerequisiteNodeIds = new List<string> { "shared_03" },
                maxLevel = 1
            },
            new ShipTraitBranchNodeEntry
            {
                branchKind = ShipTraitBranchKind.MachineGun,
                nodeId = "machinegun_01",
                displayName = "����� Ư�� 1",
                description = "����� Ʈ�� ù ��° ����Դϴ�.",
                requiredUnlockedShipCount = 1,
                maxLevel = 1
            },
            new ShipTraitBranchNodeEntry
            {
                branchKind = ShipTraitBranchKind.Sniper,
                nodeId = "sniper_01",
                displayName = "���� Ư�� 1",
                description = "�������� Ʈ�� ù ��° ����Դϴ�.",
                requiredUnlockedShipCount = 2,
                maxLevel = 1
            },
            new ShipTraitBranchNodeEntry
            {
                branchKind = ShipTraitBranchKind.Shotgun,
                nodeId = "shotgun_01",
                displayName = "���� Ư�� 1",
                description = "���� Ʈ�� ù ��° ����Դϴ�.",
                requiredUnlockedShipCount = 3,
                maxLevel = 1
            }
        };
    }

    private void Awake()
    {
        if (settlementController == null)
        {
            settlementController = FindFirstObjectByType<SettlementController>();
        }

        BindNodes();

        if (unlockButton != null)
        {
            unlockButton.onClick.AddListener(HandleUnlockButtonClick);
        }
    }

    private void OnEnable()
    {
        if (settlementController == null)
        {
            settlementController = FindFirstObjectByType<SettlementController>();
        }

        if (settlementController != null)
        {
            settlementController.Changed += HandleExternalChanged;
        }

        if (PermanentProgress.Instance != null)
        {
            PermanentProgress.Instance.Changed += HandleExternalChanged;
        }

        RefreshPanel();
    }

    private void Start()
    {
        RefreshPanel();
    }

    private void OnDisable()
    {
        if (settlementController != null)
        {
            settlementController.Changed -= HandleExternalChanged;
        }

        if (PermanentProgress.Instance != null)
        {
            PermanentProgress.Instance.Changed -= HandleExternalChanged;
        }
    }

    private void OnDestroy()
    {
        if (unlockButton != null)
        {
            unlockButton.onClick.RemoveListener(HandleUnlockButtonClick);
        }
    }

    public void SetTargetShipId(string shipId)
    {
        targetShipIdOverride = shipId;
        RefreshPanel();
    }

    public void ClearTargetShipOverride()
    {
        targetShipIdOverride = string.Empty;
        RefreshPanel();
    }

    public void SelectBranch(ShipTraitBranchKind branchKind)
    {
        ShipTraitBranchNodeEntry firstEntry = FindFirstSelectableEntry(branchKind, CountUnlockedShips());

        if (firstEntry == null)
        {
            firstEntry = FindFirstEntry(branchKind);
        }

        if (firstEntry == null)
        {
            return;
        }

        SelectNode(branchKind, GetEntryNodeId(firstEntry));
    }

    public void SelectNode(ShipTraitBranchKind branchKind, string nodeId)
    {
        selectedBranch = branchKind;
        selectedNodeId = nodeId;
        hasSelection = true;

        RefreshPanel();
    }

    public void RefreshPanel()
    {
        BindNodes();

        int unlockedShipCount = CountUnlockedShips();

        RefreshBranchPanelObjects(unlockedShipCount);
        EnsureValidSelection(unlockedShipCount);
        RefreshNodeStates(unlockedShipCount);
        RefreshDetail(unlockedShipCount);
    }

    public bool CanUnlockSelectedTrait()
    {
        ShipTraitBranchNodeEntry entry = FindEntry(selectedBranch, selectedNodeId);

        if (entry == null)
        {
            return false;
        }

        return CanUnlockEntry(entry, CountUnlockedShips());
    }

    public bool TryUnlockSelectedTrait()
    {
        ShipTraitBranchNodeEntry entry = FindEntry(selectedBranch, selectedNodeId);

        if (entry == null)
        {
            SetMessage("�ر��� Ư�� ��带 �����ϼ���.");
            return false;
        }

        int unlockedShipCount = CountUnlockedShips();

        if (!IsNodeSelectable(entry, unlockedShipCount))
        {
            SetMessage(BuildLockReason(entry, unlockedShipCount));
            return false;
        }

        PermanentProgress progress = PermanentProgress.Instance;

        if (progress == null)
        {
            SetMessage("PermanentProgress�� ���� Ư���� �ر��� �� �����ϴ�.");
            return false;
        }

        string nodeId = GetEntryNodeId(entry);
        int currentLevel = progress.GetTraitLevel(nodeId);
        int maxLevel = GetEntryMaxLevel(entry);

        if (currentLevel >= maxLevel)
        {
            SetMessage($"{GetDisplayName(entry)}�� �̹� �ִ� �����Դϴ�.");
            return false;
        }

        int scrapCost = Mathf.Max(0, entry.scrapCost);
        int coreCost = Mathf.Max(0, entry.coreShardCost);

        if (!progress.TrySpend(scrapCost, coreCost))
        {
            SetMessage($"��ȭ ����. �ʿ�: {FormatCost(scrapCost, coreCost)}");
            RefreshPanel();
            return false;
        }

        progress.SetTraitLevel(nodeId, currentLevel + 1);

        if (SaveManager.Instance != null)
        {
            SaveManager.Instance.Save(progress);
        }

        SetMessage($"{GetDisplayName(entry)} �ر� �Ϸ�. {currentLevel + 1}/{maxLevel}");
        RefreshPanel();
        return true;
    }

    private void BindNodes()
    {
        foreach (ShipTraitBranchNodeEntry entry in branchNodes)
        {
            if (entry == null || entry.nodeButton == null)
            {
                continue;
            }

            entry.nodeButton.Bind(
                this,
                entry.branchKind,
                GetEntryNodeId(entry),
                GetDisplayName(entry),
                entry.icon
            );
        }
    }

    private void RefreshBranchPanelObjects(int unlockedShipCount)
    {
        SetBranchPanelActive(
            ShipTraitBranchKind.Shared,
            IsBranchGateAvailable(ShipTraitBranchKind.Shared, unlockedShipCount)
        );

        SetBranchPanelActive(
            ShipTraitBranchKind.MachineGun,
            IsBranchGateAvailable(ShipTraitBranchKind.MachineGun, unlockedShipCount)
        );

        SetBranchPanelActive(
            ShipTraitBranchKind.Sniper,
            IsBranchGateAvailable(ShipTraitBranchKind.Sniper, unlockedShipCount)
        );

        SetBranchPanelActive(
            ShipTraitBranchKind.Shotgun,
            IsBranchGateAvailable(ShipTraitBranchKind.Shotgun, unlockedShipCount)
        );
    }

    private void SetBranchPanelActive(ShipTraitBranchKind branchKind, bool available)
    {
        GameObject panelObject = GetBranchPanelObject(branchKind);

        if (panelObject == null)
        {
            return;
        }

        if (deactivateBranchPanelWhenLocked)
        {
            panelObject.SetActive(available);
        }
        else
        {
            panelObject.SetActive(true);
        }
    }

    private GameObject GetBranchPanelObject(ShipTraitBranchKind branchKind)
    {
        return branchKind switch
        {
            ShipTraitBranchKind.Shared => sharedPanelObject,
            ShipTraitBranchKind.MachineGun => machineGunPanelObject,
            ShipTraitBranchKind.Sniper => sniperPanelObject,
            ShipTraitBranchKind.Shotgun => shotgunPanelObject,
            _ => null
        };
    }

    private bool IsBranchGateAvailable(ShipTraitBranchKind branchKind, int unlockedShipCount)
    {
        ShipTraitBranchNodeEntry gateEntry = FindFirstEntry(branchKind);

        if (gateEntry == null)
        {
            return false;
        }

        return IsEntryGateAvailable(gateEntry, unlockedShipCount);
    }

    private void EnsureValidSelection(int unlockedShipCount)
    {
        ShipTraitBranchNodeEntry selectedEntry = FindEntry(selectedBranch, selectedNodeId);

        if (!hasSelection ||
            selectedEntry == null ||
            !IsNodeSelectable(selectedEntry, unlockedShipCount))
        {
            ShipTraitBranchNodeEntry firstSelectable = FindFirstSelectableEntry(unlockedShipCount);

            if (firstSelectable != null)
            {
                selectedBranch = firstSelectable.branchKind;
                selectedNodeId = GetEntryNodeId(firstSelectable);
                hasSelection = true;
                return;
            }

            ShipTraitBranchNodeEntry firstEntry = FindFirstEntry();

            if (firstEntry != null)
            {
                selectedBranch = firstEntry.branchKind;
                selectedNodeId = GetEntryNodeId(firstEntry);
                hasSelection = true;
            }
        }
    }

    private void RefreshNodeStates(int unlockedShipCount)
    {
        foreach (ShipTraitBranchNodeEntry entry in branchNodes)
        {
            if (entry == null || entry.nodeButton == null)
            {
                continue;
            }

            bool selectable = IsNodeSelectable(entry, unlockedShipCount);
            bool unlocked = IsNodeUnlocked(entry);
            bool selected =
                hasSelection &&
                selectedBranch == entry.branchKind &&
                selectedNodeId == GetEntryNodeId(entry);

            if (entry.hideWhenLocked)
            {
                entry.nodeButton.gameObject.SetActive(selectable);
            }
            else
            {
                entry.nodeButton.gameObject.SetActive(true);
            }

            entry.nodeButton.SetVisualState(selectable, unlocked, selected);
        }
    }

    private void RefreshDetail(int unlockedShipCount)
    {
        ShipTraitBranchNodeEntry entry = FindEntry(selectedBranch, selectedNodeId);

        if (entry == null)
        {
            SetIcon(null);
            SetText(titleText, "Ư�� ����");
            SetText(bodyText, "����� Ư�� ��尡 �����ϴ�.");
            SetText(costText, string.Empty);
            SetText(statusText, string.Empty);
            SetUnlockButton(false, "Ư�� ����");
            return;
        }

        bool selectable = IsNodeSelectable(entry, unlockedShipCount);
        bool unlocked = IsNodeUnlocked(entry);
        bool canUnlock = CanUnlockEntry(entry, unlockedShipCount);

        SetIcon(entry.icon);
        SetText(titleText, GetDisplayName(entry));
        SetText(bodyText, BuildDetailText(entry, selectable, unlocked, unlockedShipCount));
        SetText(costText, BuildCostText(entry));
        SetText(statusText, BuildStatusText(entry, selectable, unlocked, unlockedShipCount));
        SetUnlockButton(canUnlock, BuildUnlockButtonLabel(entry, selectable, unlocked));
    }

    private bool CanUnlockEntry(ShipTraitBranchNodeEntry entry, int unlockedShipCount)
    {
        if (entry == null)
        {
            return false;
        }

        if (!IsNodeSelectable(entry, unlockedShipCount))
        {
            return false;
        }

        PermanentProgress progress = PermanentProgress.Instance;

        if (progress == null)
        {
            return false;
        }

        int currentLevel = progress.GetTraitLevel(GetEntryNodeId(entry));
        int maxLevel = GetEntryMaxLevel(entry);

        if (currentLevel >= maxLevel)
        {
            return false;
        }

        return progress.CanSpend(
            Mathf.Max(0, entry.scrapCost),
            Mathf.Max(0, entry.coreShardCost)
        );
    }

    private bool IsNodeSelectable(ShipTraitBranchNodeEntry entry, int unlockedShipCount)
    {
        if (!IsEntryGateAvailable(entry, unlockedShipCount))
        {
            return false;
        }

        if (!AreNodePrerequisitesMet(entry))
        {
            return false;
        }

        return true;
    }

    private bool IsEntryGateAvailable(ShipTraitBranchNodeEntry entry, int unlockedShipCount)
    {
        if (entry == null)
        {
            return false;
        }

        if (entry.requiredUnlockedShipCount > 0 &&
            unlockedShipCount < entry.requiredUnlockedShipCount)
        {
            return false;
        }

        if (!string.IsNullOrWhiteSpace(entry.requiredShipId))
        {
            ShipDefinition requiredShip = FindShipDefinition(entry.requiredShipId);

            if (requiredShip == null || !IsShipUnlocked(requiredShip))
            {
                return false;
            }
        }

        if (!string.IsNullOrWhiteSpace(entry.requiredUnlockFlag))
        {
            PermanentProgress progress = PermanentProgress.Instance;

            if (progress == null || !progress.HasUnlockFlag(entry.requiredUnlockFlag))
            {
                return false;
            }
        }

        return true;
    }

    private bool AreNodePrerequisitesMet(ShipTraitBranchNodeEntry entry)
    {
        if (entry == null)
        {
            return false;
        }

        if (entry.prerequisiteNodeIds == null || entry.prerequisiteNodeIds.Count == 0)
        {
            return true;
        }

        foreach (string prerequisiteNodeId in entry.prerequisiteNodeIds)
        {
            if (string.IsNullOrWhiteSpace(prerequisiteNodeId))
            {
                continue;
            }

            if (!IsNodeUnlocked(prerequisiteNodeId))
            {
                return false;
            }
        }

        return true;
    }

    private bool IsNodeUnlocked(ShipTraitBranchNodeEntry entry)
    {
        if (entry == null)
        {
            return false;
        }

        return IsNodeUnlocked(GetEntryNodeId(entry));
    }

    private bool IsNodeUnlocked(string nodeId)
    {
        if (string.IsNullOrWhiteSpace(nodeId))
        {
            return false;
        }

        PermanentProgress progress = PermanentProgress.Instance;

        if (progress == null)
        {
            return false;
        }

        return progress.GetTraitLevel(nodeId) > 0;
    }

    private int GetNodeLevel(ShipTraitBranchNodeEntry entry)
    {
        if (entry == null || PermanentProgress.Instance == null)
        {
            return 0;
        }

        return PermanentProgress.Instance.GetTraitLevel(GetEntryNodeId(entry));
    }

    private int GetEntryMaxLevel(ShipTraitBranchNodeEntry entry)
    {
        if (entry == null)
        {
            return 1;
        }

        return Mathf.Max(1, entry.maxLevel);
    }

    private string BuildDetailText(
        ShipTraitBranchNodeEntry entry,
        bool selectable,
        bool unlocked,
        int unlockedShipCount)
    {
        StringBuilder builder = new StringBuilder();

        string description = !string.IsNullOrWhiteSpace(entry.description)
            ? entry.description
            : GetDefaultDescription(entry.branchKind);

        int currentLevel = GetNodeLevel(entry);
        int maxLevel = GetEntryMaxLevel(entry);

        builder.AppendLine(description);
        builder.AppendLine();

        builder.AppendLine($"��� ID: {GetEntryNodeId(entry)}");
        builder.AppendLine($"�귣ġ: {GetBranchDisplayName(entry.branchKind)}");
        builder.AppendLine($"����: {currentLevel}/{maxLevel}");
        builder.AppendLine($"����: {BuildStatusText(entry, selectable, unlocked, unlockedShipCount)}");

        if (entry.requiredUnlockedShipCount > 0)
        {
            builder.AppendLine($"�ʿ� �ر� ��ü ��: {entry.requiredUnlockedShipCount}");
            builder.AppendLine($"���� �ر� ��ü ��: {unlockedShipCount}");
        }

        if (!string.IsNullOrWhiteSpace(entry.requiredShipId))
        {
            ShipDefinition requiredShip = FindShipDefinition(entry.requiredShipId);
            string shipName = requiredShip != null ? requiredShip.DisplayName : entry.requiredShipId;
            bool shipUnlocked = requiredShip != null && IsShipUnlocked(requiredShip);

            builder.AppendLine($"�ʿ� ��ü: {shipName} / {(shipUnlocked ? "�رݵ�" : "���")}");
        }

        if (!string.IsNullOrWhiteSpace(entry.requiredUnlockFlag))
        {
            bool flagUnlocked = PermanentProgress.Instance != null &&
                                PermanentProgress.Instance.HasUnlockFlag(entry.requiredUnlockFlag);

            builder.AppendLine($"�ʿ� �÷���: {entry.requiredUnlockFlag} / {(flagUnlocked ? "����" : "�̺���")}");
        }

        if (entry.prerequisiteNodeIds != null && entry.prerequisiteNodeIds.Count > 0)
        {
            builder.AppendLine();
            builder.AppendLine("���� ���:");

            foreach (string prerequisiteNodeId in entry.prerequisiteNodeIds)
            {
                if (string.IsNullOrWhiteSpace(prerequisiteNodeId))
                {
                    continue;
                }

                builder.AppendLine($"- {prerequisiteNodeId}: {(IsNodeUnlocked(prerequisiteNodeId) ? "�رݵ�" : "���")}");
            }
        }

        if (!selectable)
        {
            builder.AppendLine();
            builder.AppendLine(BuildLockReason(entry, unlockedShipCount));
        }

        return builder.ToString().TrimEnd();
    }

    private string BuildStatusText(
        ShipTraitBranchNodeEntry entry,
        bool selectable,
        bool unlocked,
        int unlockedShipCount)
    {
        if (entry == null)
        {
            return "����";
        }

        if (!IsEntryGateAvailable(entry, unlockedShipCount))
        {
            return "�귣ġ ���";
        }

        if (!AreNodePrerequisitesMet(entry))
        {
            return "���� Ư�� �ʿ�";
        }

        if (unlocked)
        {
            int currentLevel = GetNodeLevel(entry);
            int maxLevel = GetEntryMaxLevel(entry);

            if (currentLevel >= maxLevel)
            {
                return "�ִ� ����";
            }

            return "��ȭ ����";
        }

        if (!selectable)
        {
            return "���";
        }

        PermanentProgress progress = PermanentProgress.Instance;

        if (progress == null)
        {
            return "���� ������ ����";
        }

        if (!progress.CanSpend(Mathf.Max(0, entry.scrapCost), Mathf.Max(0, entry.coreShardCost)))
        {
            return "��ȭ ����";
        }

        return "�ر� ����";
    }

    private string BuildLockReason(ShipTraitBranchNodeEntry entry, int unlockedShipCount)
    {
        if (entry == null)
        {
            return "��� �����Ͱ� �����ϴ�.";
        }

        if (entry.requiredUnlockedShipCount > 0 &&
            unlockedShipCount < entry.requiredUnlockedShipCount)
        {
            return $"��ü �ر� ���� �����մϴ�. {unlockedShipCount}/{entry.requiredUnlockedShipCount}";
        }

        if (!string.IsNullOrWhiteSpace(entry.requiredShipId))
        {
            ShipDefinition requiredShip = FindShipDefinition(entry.requiredShipId);

            if (requiredShip == null || !IsShipUnlocked(requiredShip))
            {
                return $"�ʿ� ��ü�� ���� �رݵ��� �ʾҽ��ϴ�. �ʿ� ��ü ID: {entry.requiredShipId}";
            }
        }

        if (!string.IsNullOrWhiteSpace(entry.requiredUnlockFlag))
        {
            PermanentProgress progress = PermanentProgress.Instance;

            if (progress == null || !progress.HasUnlockFlag(entry.requiredUnlockFlag))
            {
                return $"�ʿ� �ر� �÷��װ� �����ϴ�. �ʿ� �÷���: {entry.requiredUnlockFlag}";
            }
        }

        if (entry.prerequisiteNodeIds != null)
        {
            foreach (string prerequisiteNodeId in entry.prerequisiteNodeIds)
            {
                if (string.IsNullOrWhiteSpace(prerequisiteNodeId))
                {
                    continue;
                }

                if (!IsNodeUnlocked(prerequisiteNodeId))
                {
                    return $"���� Ư���� �ʿ��մϴ�. �ʿ� ���: {prerequisiteNodeId}";
                }
            }
        }

        return "���";
    }

    private string BuildCostText(ShipTraitBranchNodeEntry entry)
    {
        if (entry == null)
        {
            return string.Empty;
        }

        int scrapCost = Mathf.Max(0, entry.scrapCost);
        int coreCost = Mathf.Max(0, entry.coreShardCost);

        if (scrapCost <= 0 && coreCost <= 0)
        {
            return "��� ����";
        }

        return $"�ʿ� ��ȭ: {FormatCost(scrapCost, coreCost)}";
    }

    private string BuildUnlockButtonLabel(
        ShipTraitBranchNodeEntry entry,
        bool selectable,
        bool unlocked)
    {
        if (entry == null)
        {
            return "Ư�� ����";
        }

        int currentLevel = GetNodeLevel(entry);
        int maxLevel = GetEntryMaxLevel(entry);

        if (!selectable)
        {
            return "���";
        }

        if (currentLevel >= maxLevel)
        {
            return "�ִ� ����";
        }

        if (unlocked)
        {
            return $"��ȭ {currentLevel}/{maxLevel}";
        }

        return "�ر�";
    }

    private string FormatCost(int scrapCost, int coreCost)
    {
        if (scrapCost <= 0 && coreCost <= 0)
        {
            return "����";
        }

        StringBuilder builder = new StringBuilder();

        if (scrapCost > 0)
        {
            builder.Append($"��ũ�� {scrapCost}");
        }

        if (coreCost > 0)
        {
            if (builder.Length > 0)
            {
                builder.Append(" / ");
            }

            builder.Append($"�ھ� {coreCost}");
        }

        return builder.ToString();
    }

    private int CountUnlockedShips()
    {
        List<ShipDefinition> ships = CollectShipDefinitions();

        if (ships.Count == 0)
        {
            return 1;
        }

        int count = 0;
        HashSet<string> countedIds = new HashSet<string>();

        foreach (ShipDefinition ship in ships)
        {
            if (ship == null)
            {
                continue;
            }

            if (!countedIds.Add(ship.ShipId))
            {
                continue;
            }

            if (IsShipUnlocked(ship))
            {
                count++;
            }
        }

        return Mathf.Max(0, count);
    }

    private List<ShipDefinition> CollectShipDefinitions()
    {
        List<ShipDefinition> result = new List<ShipDefinition>();
        HashSet<string> ids = new HashSet<string>();

        AddShipDefinitions(result, ids, shipDefinitions);

        if (settlementController != null && settlementController.ShipDefinitions != null)
        {
            AddShipDefinitions(result, ids, settlementController.ShipDefinitions);
        }

        return result;
    }

    private void AddShipDefinitions(
        List<ShipDefinition> result,
        HashSet<string> ids,
        IEnumerable<ShipDefinition> source)
    {
        if (source == null)
        {
            return;
        }

        foreach (ShipDefinition ship in source)
        {
            if (ship == null)
            {
                continue;
            }

            if (ids.Add(ship.ShipId))
            {
                result.Add(ship);
            }
        }
    }

    private bool IsShipUnlocked(ShipDefinition ship)
    {
        if (ship == null)
        {
            return false;
        }

        if (settlementController != null)
        {
            return settlementController.IsShipUnlocked(ship);
        }

        if (ship.UnlockedByDefault)
        {
            return true;
        }

        PermanentProgress progress = PermanentProgress.Instance;
        return progress != null && progress.HasUnlockFlag(ship.UnlockFlag);
    }

    private ShipDefinition FindShipDefinition(string shipId)
    {
        if (string.IsNullOrWhiteSpace(shipId))
        {
            return null;
        }

        foreach (ShipDefinition ship in shipDefinitions)
        {
            if (ship != null && ship.ShipId == shipId)
            {
                return ship;
            }
        }

        if (settlementController != null && settlementController.ShipDefinitions != null)
        {
            foreach (ShipDefinition ship in settlementController.ShipDefinitions)
            {
                if (ship != null && ship.ShipId == shipId)
                {
                    return ship;
                }
            }
        }

        return null;
    }

    private ShipTraitBranchNodeEntry FindEntry(ShipTraitBranchKind branchKind, string nodeId)
    {
        foreach (ShipTraitBranchNodeEntry entry in branchNodes)
        {
            if (entry == null)
            {
                continue;
            }

            if (entry.branchKind != branchKind)
            {
                continue;
            }

            if (GetEntryNodeId(entry) == nodeId)
            {
                return entry;
            }
        }

        return null;
    }

    private ShipTraitBranchNodeEntry FindFirstEntry(ShipTraitBranchKind branchKind)
    {
        foreach (ShipTraitBranchNodeEntry entry in branchNodes)
        {
            if (entry != null && entry.branchKind == branchKind)
            {
                return entry;
            }
        }

        return null;
    }

    private ShipTraitBranchNodeEntry FindFirstEntry()
    {
        foreach (ShipTraitBranchNodeEntry entry in branchNodes)
        {
            if (entry != null)
            {
                return entry;
            }
        }

        return null;
    }

    private ShipTraitBranchNodeEntry FindFirstSelectableEntry(ShipTraitBranchKind branchKind, int unlockedShipCount)
    {
        foreach (ShipTraitBranchNodeEntry entry in branchNodes)
        {
            if (entry == null)
            {
                continue;
            }

            if (entry.branchKind != branchKind)
            {
                continue;
            }

            if (IsNodeSelectable(entry, unlockedShipCount))
            {
                return entry;
            }
        }

        return null;
    }

    private ShipTraitBranchNodeEntry FindFirstSelectableEntry(int unlockedShipCount)
    {
        foreach (ShipTraitBranchNodeEntry entry in branchNodes)
        {
            if (entry != null && IsNodeSelectable(entry, unlockedShipCount))
            {
                return entry;
            }
        }

        return null;
    }

    private string GetEntryNodeId(ShipTraitBranchNodeEntry entry)
    {
        if (entry == null)
        {
            return string.Empty;
        }

        if (!string.IsNullOrWhiteSpace(entry.nodeId))
        {
            return entry.nodeId;
        }

        if (entry.nodeButton != null && !string.IsNullOrWhiteSpace(entry.nodeButton.NodeId))
        {
            return entry.nodeButton.NodeId;
        }

        int index = branchNodes.IndexOf(entry);
        return $"{entry.branchKind}_{index}";
    }

    private string GetDisplayName(ShipTraitBranchNodeEntry entry)
    {
        if (entry == null)
        {
            return "Ư��";
        }

        if (!string.IsNullOrWhiteSpace(entry.displayName))
        {
            return entry.displayName;
        }

        return GetBranchDisplayName(entry.branchKind);
    }

    private string GetBranchDisplayName(ShipTraitBranchKind branchKind)
    {
        return branchKind switch
        {
            ShipTraitBranchKind.Shared => "���� Ư��",
            ShipTraitBranchKind.MachineGun => "����� Ư��",
            ShipTraitBranchKind.Sniper => "���� Ư��",
            ShipTraitBranchKind.Shotgun => "���� Ư��",
            _ => "Ư��"
        };
    }

    private string GetDefaultDescription(ShipTraitBranchKind branchKind)
    {
        return branchKind switch
        {
            ShipTraitBranchKind.Shared =>
                "��� ��ü�� ���� Ʈ���� �������� ����Ǵ� Ư�� �׷��Դϴ�.",

            ShipTraitBranchKind.MachineGun =>
                "����� Ʈ�� ���� Ư�� �׷��Դϴ�. ���� ��ݰ� ���� ������ ��ȭ�մϴ�.",

            ShipTraitBranchKind.Sniper =>
                "�������� Ʈ�� ���� Ư�� �׷��Դϴ�. ��¡, ����, ��Ÿ� ������ ��ȭ�մϴ�.",

            ShipTraitBranchKind.Shotgun =>
                "���� Ʈ�� ���� Ư�� �׷��Դϴ�. ����, ��ź, �ٰŸ� ������ ��ȭ�մϴ�.",

            _ => "Ư�� �׷��Դϴ�."
        };
    }

    private string ResolveTargetShipId()
    {
        if (!string.IsNullOrWhiteSpace(targetShipIdOverride))
        {
            return targetShipIdOverride;
        }

        if (settlementController != null)
        {
            return settlementController.SelectedShipId;
        }

        if (PermanentProgress.Instance != null)
        {
            return PermanentProgress.Instance.SelectedShipId;
        }

        return "basic_ship";
    }

    private void SetIcon(Sprite icon)
    {
        if (selectedIconImage == null)
        {
            return;
        }

        selectedIconImage.sprite = icon;
        selectedIconImage.enabled = icon != null;
        selectedIconImage.preserveAspect = true;
    }

    private void SetUnlockButton(bool interactable, string label)
    {
        if (unlockButton != null)
        {
            unlockButton.interactable = interactable;
        }

        SetText(unlockButtonLabelText, label);
    }

    private void SetText(TextMeshProUGUI target, string value)
    {
        if (target != null)
        {
            target.text = value;
        }
    }

    private void SetMessage(string message)
    {
        SetText(messageText, message);
        Debug.Log(message, this);
    }

    private void HandleUnlockButtonClick()
    {
        TryUnlockSelectedTrait();
    }

    private void HandleExternalChanged()
    {
        RefreshPanel();
    }
}